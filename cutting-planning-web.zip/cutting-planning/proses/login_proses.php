<?php
session_start();
include '../config/database.php';

$username = mysqli_real_escape_string($conn, $_POST['username']);
$password = md5($_POST['password']);

$query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username' AND password='$password'");

if (mysqli_num_rows($query) > 0) {
    $data = mysqli_fetch_assoc($query);
    $_SESSION['id']       = $data['id'];
    $_SESSION['nama']     = $data['nama'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['level']    = $data['level'];
    header("Location: ../pages/dashboard.php");
} else {
    header("Location: ../pages/login.php?error=1");
}
exit;
?>
