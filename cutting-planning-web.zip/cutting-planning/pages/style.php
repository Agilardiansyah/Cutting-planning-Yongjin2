<?php
include 'header.php';
include '../config/database.php';

// Proses tambah / edit / hapus
if (isset($_POST['simpan'])) {
    $kode = mysqli_real_escape_string($conn, $_POST['kode_style']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama_style']);
    $desk = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    
    if ($_POST['id'] == '') {
        mysqli_query($conn, "INSERT INTO style (kode_style, nama_style, deskripsi) VALUES ('$kode','$nama','$desk')");
    } else {
        $id = intval($_POST['id']);
        mysqli_query($conn, "UPDATE style SET kode_style='$kode', nama_style='$nama', deskripsi='$desk' WHERE id=$id");
    }
    header("Location: style.php?sukses=1");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM style WHERE id=$id");
    header("Location: style.php?sukses=1");
    exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $edit = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM style WHERE id=$id"));
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-tags"></i> Data Style / Artikel</h5>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalStyle">
        <i class="bi bi-plus-lg"></i> Tambah Style
    </button>
</div>

<?php if (isset($_GET['sukses'])): ?>
<div class="alert alert-success alert-dismissible fade show py-2">Data berhasil disimpan!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th width="50">No</th>
                        <th>Kode Style</th>
                        <th>Nama Style</th>
                        <th>Deskripsi</th>
                        <th width="120">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $q = mysqli_query($conn, "SELECT * FROM style ORDER BY id DESC");
                    if (mysqli_num_rows($q) > 0):
                        while ($row = mysqli_fetch_assoc($q)):
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($row['kode_style']) ?></strong></td>
                        <td><?= htmlspecialchars($row['nama_style']) ?></td>
                        <td><?= htmlspecialchars($row['deskripsi']) ?></td>
                        <td>
                            <a href="?edit=<?= $row['id'] ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil"></i></a>
                            <a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">Belum ada data style</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalStyle" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?= $edit ? 'Edit' : 'Tambah' ?> Style</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">
                <div class="mb-3">
                    <label class="form-label">Kode Style</label>
                    <input type="text" name="kode_style" class="form-control" value="<?= $edit['kode_style'] ?? '' ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama Style</label>
                    <input type="text" name="nama_style" class="form-control" value="<?= $edit['nama_style'] ?? '' ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" rows="2"><?= $edit['deskripsi'] ?? '' ?></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<?php if ($edit): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var modal = new bootstrap.Modal(document.getElementById('modalStyle'));
        modal.show();
    });
</script>
<?php endif; ?>

<?php include 'footer.php'; ?>
