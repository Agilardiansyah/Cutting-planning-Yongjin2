<?php
include 'header.php';
include '../config/database.php';

// Proses simpan order
if (isset($_POST['simpan_order'])) {
    $no_order = mysqli_real_escape_string($conn, $_POST['no_order']);
    $id_style = intval($_POST['id_style']);
    $warna    = mysqli_real_escape_string($conn, $_POST['warna']);
    $tanggal  = $_POST['tanggal'];
    
    $sizes = $_POST['size'] ?? [];
    $qtys  = $_POST['qty'] ?? [];
    $total_qty = 0;
    foreach ($qtys as $q) $total_qty += intval($q);
    
    mysqli_query($conn, "INSERT INTO orders (no_order, id_style, warna, total_qty, tanggal) 
                         VALUES ('$no_order', $id_style, '$warna', $total_qty, '$tanggal')");
    $id_order = mysqli_insert_id($conn);
    
    for ($i = 0; $i < count($sizes); $i++) {
        $size = mysqli_real_escape_string($conn, $sizes[$i]);
        $qty  = intval($qtys[$i]);
        if ($qty > 0) {
            mysqli_query($conn, "INSERT INTO order_detail (id_order, size, qty) VALUES ($id_order, '$size', $qty)");
        }
    }
    header("Location: order.php?sukses=1");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM order_detail WHERE id_order=$id");
    mysqli_query($conn, "DELETE FROM orders WHERE id=$id");
    header("Location: order.php?sukses=1");
    exit;
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-cart"></i> Data Order</h5>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalOrder">
        <i class="bi bi-plus-lg"></i> Tambah Order
    </button>
</div>

<?php if (isset($_GET['sukses'])): ?>
<div class="alert alert-success alert-dismissible fade show py-2">Data berhasil disimpan!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>No Order</th>
                        <th>Style</th>
                        <th>Warna</th>
                        <th>Total Qty</th>
                        <th>Tanggal</th>
                        <th>Status</th>
                        <th width="100">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $q = mysqli_query($conn, "SELECT o.*, s.nama_style FROM orders o JOIN style s ON o.id_style = s.id ORDER BY o.id DESC");
                    if (mysqli_num_rows($q) > 0):
                        while ($row = mysqli_fetch_assoc($q)):
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($row['no_order']) ?></strong></td>
                        <td><?= htmlspecialchars($row['nama_style']) ?></td>
                        <td><?= htmlspecialchars($row['warna']) ?></td>
                        <td><?= number_format($row['total_qty']) ?></td>
                        <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                        <td>
                            <?php
                            $badge = ['pending'=>'secondary','proses'=>'primary','selesai'=>'success'];
                            echo '<span class="badge bg-'.$badge[$row['status']].'">'.ucfirst($row['status']).'</span>';
                            ?>
                        </td>
                        <td>
                            <a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus order ini?')"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data order</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Order -->
<div class="modal fade" id="modalOrder" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Order Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">No Order</label>
                        <input type="text" name="no_order" class="form-control" required placeholder="Contoh: ORD-001">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Style</label>
                        <select name="id_style" class="form-select" required>
                            <option value="">-- Pilih Style --</option>
                            <?php
                            $styles = mysqli_query($conn, "SELECT * FROM style ORDER BY nama_style");
                            while ($s = mysqli_fetch_assoc($styles)):
                            ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['kode_style'].' - '.$s['nama_style']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Warna</label>
                        <input type="text" name="warna" class="form-control" required placeholder="Contoh: Black">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Tanggal Order</label>
                        <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                
                <hr>
                <h6>Size Ratio / Quantity</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Size</th>
                                <th>Quantity</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $size_list = ['XS','S','M','L','XL','XXL','3XL'];
                            foreach ($size_list as $sz):
                            ?>
                            <tr>
                                <td>
                                    <input type="hidden" name="size[]" value="<?= $sz ?>">
                                    <strong><?= $sz ?></strong>
                                </td>
                                <td>
                                    <input type="number" name="qty[]" class="form-control form-control-sm" min="0" value="0">
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" name="simpan_order" class="btn btn-primary">Simpan Order</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
