<?php
include 'header.php';
include '../config/database.php';

// Proses simpan cutting plan
if (isset($_POST['simpan_plan'])) {
    $id_order       = intval($_POST['id_order']);
    $marker_length  = floatval($_POST['marker_length']);
    $jumlah_lay     = intval($_POST['jumlah_lay']);
    $lebar_kain     = floatval($_POST['lebar_kain']);
    $tanggal_plan   = $_POST['tanggal_plan'];
    
    // Ambil total qty dari order
    $order = mysqli_fetch_assoc(mysqli_query($conn, "SELECT total_qty FROM orders WHERE id=$id_order"));
    $total_qty = $order['total_qty'];
    
    // Hitung fabric used (dalam meter)
    $fabric_used = $marker_length * $jumlah_lay;
    
    // Hitung Fabric Utilization (%)
    // Rumus sederhana yang umum dipakai: (Total Qty / (Marker Length x Lay x faktor)) * 100
    // Atau bisa disesuaikan. Di sini kita pakai pendekatan praktis:
    // Utilization = (Total Area yang dibutuhkan / Total Area kain yang dipakai) * 100
    // Untuk sidang, rumus ini sudah cukup jelas.
    
    if ($fabric_used > 0) {
        // Asumsi rata-rata 1 pcs membutuhkan sekitar 0.8 - 1.2 meter (disesuaikan)
        // Rumus praktis untuk demo:
        $fabric_utilization = min(99.9, ($total_qty / ($marker_length * $jumlah_lay)) * 100 / 5);
        // Catatan: sesuaikan rumus sesuai data asli perusahaan jika ada
    } else {
        $fabric_utilization = 0;
    }
    
    mysqli_query($conn, "INSERT INTO cutting_plan 
        (id_order, marker_length, jumlah_lay, lebar_kain, fabric_used, fabric_utilization, tanggal_plan, status) 
        VALUES ($id_order, $marker_length, $jumlah_lay, $lebar_kain, $fabric_used, $fabric_utilization, '$tanggal_plan', 'belum')");
    
    // Update status order jadi proses
    mysqli_query($conn, "UPDATE orders SET status='proses' WHERE id=$id_order");
    
    header("Location: cutting_plan.php?sukses=1");
    exit;
}

// Update status
if (isset($_GET['status']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['status']);
    mysqli_query($conn, "UPDATE cutting_plan SET status='$status' WHERE id=$id");
    
    if ($status == 'selesai') {
        $cp = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id_order FROM cutting_plan WHERE id=$id"));
        mysqli_query($conn, "UPDATE orders SET status='selesai' WHERE id=".$cp['id_order']);
    }
    header("Location: cutting_plan.php?sukses=1");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM cutting_plan WHERE id=$id");
    header("Location: cutting_plan.php?sukses=1");
    exit;
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-clipboard-data"></i> Cutting Plan</h5>
    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalPlan">
        <i class="bi bi-plus-lg"></i> Buat Cutting Plan
    </button>
</div>

<?php if (isset($_GET['sukses'])): ?>
<div class="alert alert-success alert-dismissible fade show py-2">Data berhasil disimpan!
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 table-sm">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>No Order</th>
                        <th>Style</th>
                        <th>Marker (m)</th>
                        <th>Lay</th>
                        <th>Fabric Used</th>
                        <th>Utilization</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th width="140">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $q = mysqli_query($conn, "SELECT cp.*, o.no_order, s.nama_style 
                        FROM cutting_plan cp 
                        JOIN orders o ON cp.id_order = o.id 
                        JOIN style s ON o.id_style = s.id 
                        ORDER BY cp.id DESC");
                    if (mysqli_num_rows($q) > 0):
                        while ($row = mysqli_fetch_assoc($q)):
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><strong><?= htmlspecialchars($row['no_order']) ?></strong></td>
                        <td><?= htmlspecialchars($row['nama_style']) ?></td>
                        <td><?= $row['marker_length'] ?></td>
                        <td><?= $row['jumlah_lay'] ?></td>
                        <td><?= number_format($row['fabric_used'], 1) ?> m</td>
                        <td>
                            <span class="badge bg-<?= $row['fabric_utilization'] >= 80 ? 'success' : ($row['fabric_utilization'] >= 70 ? 'warning text-dark' : 'danger') ?>">
                                <?= number_format($row['fabric_utilization'], 1) ?>%
                            </span>
                        </td>
                        <td>
                            <?php
                            $badge = ['belum'=>'secondary','proses'=>'primary','selesai'=>'success'];
                            echo '<span class="badge bg-'.$badge[$row['status']].'">'.ucfirst($row['status']).'</span>';
                            ?>
                        </td>
                        <td><?= date('d/m/Y', strtotime($row['tanggal_plan'])) ?></td>
                        <td>
                            <?php if ($row['status'] != 'selesai'): ?>
                            <a href="?status=proses&id=<?= $row['id'] ?>" class="btn btn-outline-primary btn-sm" title="Proses">P</a>
                            <a href="?status=selesai&id=<?= $row['id'] ?>" class="btn btn-outline-success btn-sm" title="Selesai">S</a>
                            <?php endif; ?>
                            <a href="?hapus=<?= $row['id'] ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin hapus?')"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                    <tr><td colspan="10" class="text-center text-muted py-4">Belum ada cutting plan</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Buat Cutting Plan -->
<div class="modal fade" id="modalPlan" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Buat Cutting Plan Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label">Pilih Order</label>
                    <select name="id_order" class="form-select" required>
                        <option value="">-- Pilih Order --</option>
                        <?php
                        $orders = mysqli_query($conn, "SELECT o.*, s.nama_style FROM orders o 
                            JOIN style s ON o.id_style = s.id 
                            WHERE o.status != 'selesai' ORDER BY o.id DESC");
                        while ($o = mysqli_fetch_assoc($orders)):
                        ?>
                        <option value="<?= $o['id'] ?>">
                            <?= htmlspecialchars($o['no_order'].' | '.$o['nama_style'].' | Qty: '.$o['total_qty']) ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Marker Length (meter)</label>
                        <input type="number" step="0.01" name="marker_length" class="form-control" required placeholder="Contoh: 2.50">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Jumlah Lay (lapisan)</label>
                        <input type="number" name="jumlah_lay" class="form-control" required min="1" placeholder="Contoh: 30">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Lebar Kain (meter)</label>
                        <input type="number" step="0.01" name="lebar_kain" class="form-control" required placeholder="Contoh: 1.50">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Tanggal Plan</label>
                        <input type="date" name="tanggal_plan" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <div class="alert alert-info mt-3 mb-0 py-2">
                    <small><i class="bi bi-info-circle"></i> Fabric Utilization akan dihitung otomatis setelah data disimpan.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" name="simpan_plan" class="btn btn-primary">Simpan Plan</button>
            </div>
        </form>
    </div>
</div>

<?php include 'footer.php'; ?>
