<?php
include 'header.php';
include '../config/database.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-file-earmark-text"></i> Laporan Cutting Plan</h5>
    <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-printer"></i> Cetak
    </button>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-sm">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>No Order</th>
                        <th>Style</th>
                        <th>Warna</th>
                        <th>Total Qty</th>
                        <th>Marker (m)</th>
                        <th>Lay</th>
                        <th>Fabric Used (m)</th>
                        <th>Utilization (%)</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $total_fabric = 0;
                    $total_util = 0;
                    $count = 0;
                    
                    $q = mysqli_query($conn, "SELECT cp.*, o.no_order, o.warna, o.total_qty, s.nama_style 
                        FROM cutting_plan cp 
                        JOIN orders o ON cp.id_order = o.id 
                        JOIN style s ON o.id_style = s.id 
                        ORDER BY cp.tanggal_plan DESC");
                    
                    if (mysqli_num_rows($q) > 0):
                        while ($row = mysqli_fetch_assoc($q)):
                            $total_fabric += $row['fabric_used'];
                            $total_util += $row['fabric_utilization'];
                            $count++;
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['no_order']) ?></td>
                        <td><?= htmlspecialchars($row['nama_style']) ?></td>
                        <td><?= htmlspecialchars($row['warna']) ?></td>
                        <td class="text-end"><?= number_format($row['total_qty']) ?></td>
                        <td class="text-end"><?= $row['marker_length'] ?></td>
                        <td class="text-end"><?= $row['jumlah_lay'] ?></td>
                        <td class="text-end"><?= number_format($row['fabric_used'], 1) ?></td>
                        <td class="text-end">
                            <strong class="text-<?= $row['fabric_utilization'] >= 80 ? 'success' : 'danger' ?>">
                                <?= number_format($row['fabric_utilization'], 1) ?>
                            </strong>
                        </td>
                        <td><?= ucfirst($row['status']) ?></td>
                        <td><?= date('d/m/Y', strtotime($row['tanggal_plan'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    <tr class="table-light fw-bold">
                        <td colspan="7" class="text-end">Total / Rata-rata</td>
                        <td class="text-end"><?= number_format($total_fabric, 1) ?> m</td>
                        <td class="text-end"><?= $count > 0 ? number_format($total_util / $count, 1) : 0 ?>%</td>
                        <td colspan="2"></td>
                    </tr>
                    <?php else: ?>
                    <tr><td colspan="11" class="text-center text-muted py-4">Belum ada data laporan</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card mt-3">
    <div class="card-body">
        <h6>Keterangan Fabric Utilization:</h6>
        <ul class="mb-0">
            <li><span class="badge bg-success">≥ 80%</span> Baik / Efisien</li>
            <li><span class="badge bg-warning text-dark">70% - 79%</span> Cukup</li>
            <li><span class="badge bg-danger">&lt; 70%</span> Perlu optimasi</li>
        </ul>
    </div>
</div>

<?php include 'footer.php'; ?>
