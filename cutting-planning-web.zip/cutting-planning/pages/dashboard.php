<?php
include 'header.php';
include '../config/database.php';

// Hitung statistik
$total_style   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM style"))['jml'];
$total_order   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM orders"))['jml'];
$total_plan    = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM cutting_plan"))['jml'];
$plan_selesai  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM cutting_plan WHERE status='selesai'"))['jml'];

// Ambil rata-rata utilization
$avg_util = mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(fabric_utilization) as rata FROM cutting_plan WHERE fabric_utilization > 0"));
$avg_util = $avg_util['rata'] ? number_format($avg_util['rata'], 1) : 0;
?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card stat-card p-3">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="text-muted mb-1">Total Style</h6>
                    <h3 class="mb-0"><?= $total_style ?></h3>
                </div>
                <i class="bi bi-tags fs-1 text-primary opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card p-3">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="text-muted mb-1">Total Order</h6>
                    <h3 class="mb-0"><?= $total_order ?></h3>
                </div>
                <i class="bi bi-cart fs-1 text-success opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card p-3">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="text-muted mb-1">Cutting Plan</h6>
                    <h3 class="mb-0"><?= $total_plan ?></h3>
                </div>
                <i class="bi bi-clipboard-data fs-1 text-warning opacity-50"></i>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card p-3">
            <div class="d-flex justify-content-between">
                <div>
                    <h6 class="text-muted mb-1">Avg Utilization</h6>
                    <h3 class="mb-0"><?= $avg_util ?>%</h3>
                </div>
                <i class="bi bi-percent fs-1 text-danger opacity-50"></i>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="bi bi-clock-history"></i> Cutting Plan Terbaru</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>No Order</th>
                                <th>Style</th>
                                <th>Utilization</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $q = mysqli_query($conn, "SELECT cp.*, o.no_order, s.nama_style 
                                FROM cutting_plan cp 
                                JOIN orders o ON cp.id_order = o.id 
                                JOIN style s ON o.id_style = s.id 
                                ORDER BY cp.id DESC LIMIT 8");
                            if (mysqli_num_rows($q) > 0):
                                while ($row = mysqli_fetch_assoc($q)):
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($row['no_order']) ?></td>
                                <td><?= htmlspecialchars($row['nama_style']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $row['fabric_utilization'] >= 80 ? 'success' : ($row['fabric_utilization'] >= 70 ? 'warning' : 'danger') ?>">
                                        <?= number_format($row['fabric_utilization'], 1) ?>%
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $badge = ['belum'=>'secondary','proses'=>'primary','selesai'=>'success'];
                                    echo '<span class="badge bg-'.$badge[$row['status']].'">'.ucfirst($row['status']).'</span>';
                                    ?>
                                </td>
                                <td><?= date('d/m/Y', strtotime($row['tanggal_plan'])) ?></td>
                            </tr>
                            <?php endwhile; else: ?>
                            <tr><td colspan="5" class="text-center text-muted py-4">Belum ada data cutting plan</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header bg-white">
                <h6 class="mb-0"><i class="bi bi-info-circle"></i> Informasi</h6>
            </div>
            <div class="card-body">
                <p class="mb-2"><strong>Plan Selesai:</strong> <?= $plan_selesai ?> / <?= $total_plan ?></p>
                <div class="progress mb-3" style="height: 10px;">
                    <?php $persen = $total_plan > 0 ? ($plan_selesai / $total_plan * 100) : 0; ?>
                    <div class="progress-bar bg-success" style="width: <?= $persen ?>%"></div>
                </div>
                <hr>
                <small class="text-muted">
                    Sistem ini digunakan untuk membantu perencanaan cutting, menghitung fabric utilization, dan monitoring progress di PT Yongjin Javasuka Garment.
                </small>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
