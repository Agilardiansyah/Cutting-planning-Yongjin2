<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cutting Planning - PT Yongjin Javasuka Garment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 250px;
            --primary: #1e3c72;
        }
        body {
            background-color: #f4f6f9;
        }
        .sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: var(--primary);
            color: white;
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar .brand {
            padding: 20px 15px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }
        .sidebar .nav-link {
            color: rgba(255,255,255,0.85);
            padding: 12px 20px;
            border-radius: 0;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background: rgba(255,255,255,0.15);
            color: white;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: 100vh;
        }
        .navbar-top {
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            border-radius: 8px;
            padding: 12px 20px;
        }
        .card {
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            border-radius: 10px;
        }
        .stat-card {
            border-left: 4px solid var(--primary);
        }
        @media (max-width: 768px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="brand">
            <i class="bi bi-scissors fs-3"></i>
            <h5 class="mt-2 mb-0">Cutting Planning</h5>
            <small class="opacity-75">Yongjin Javasuka</small>
        </div>
        <nav class="nav flex-column mt-3">
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'style.php' ? 'active' : '' ?>" href="style.php">
                <i class="bi bi-tags me-2"></i> Data Style
            </a>
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'order.php' ? 'active' : '' ?>" href="order.php">
                <i class="bi bi-cart me-2"></i> Data Order
            </a>
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'cutting_plan.php' ? 'active' : '' ?>" href="cutting_plan.php">
                <i class="bi bi-clipboard-data me-2"></i> Cutting Plan
            </a>
            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : '' ?>" href="laporan.php">
                <i class="bi bi-file-earmark-text me-2"></i> Laporan
            </a>
            <hr class="border-secondary mx-3">
            <a class="nav-link" href="../logout.php">
                <i class="bi bi-box-arrow-left me-2"></i> Logout
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="navbar-top d-flex justify-content-between align-items-center">
            <div>
                <h5 class="mb-0">Sistem Informasi Cutting Planning</h5>
                <small class="text-muted">PT Yongjin Javasuka Garment</small>
            </div>
            <div>
                <span class="me-3"><i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['nama']); ?></span>
            </div>
        </div>
